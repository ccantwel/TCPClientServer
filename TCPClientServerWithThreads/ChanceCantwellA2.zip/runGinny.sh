#!/bin/bash
    bin/client "ginny.socs.uoguelph.ca:12008" "ShakespereHamlet.txt" "500"
    bin/client "ginny.socs.uoguelph.ca:12008" "VirtualLightLong.txt" "500"
echo Finished
