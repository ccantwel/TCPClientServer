#!/bin/bash
    bin/client "localhost:12008" "ShakespereHamlet.txt" "500"
    bin/client "localhost:12008" "VirtualLightLong.txt" "500"
echo Finished

